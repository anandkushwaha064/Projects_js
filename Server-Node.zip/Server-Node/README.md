# Simple blog with reactjs and node.js

## setup
- clone this repo
- run `npm install && cd client && npm install` to install dependencies
- make .env file with sample from .env.sample
- run `npm start && cd client && npm start`
- server is on `localhost:5000` frontend is on `localhost:3000`