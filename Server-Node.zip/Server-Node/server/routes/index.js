const express = require('express');
// const catchErrors = require('../handlers/errorhandler');
const blogController = require('../controllers/blogController');
const appRouter = express.Router();
appRouter.get('/supplyDetails', blogController.getAllBlogPosts);
// appRouter.post('/posts/upload', authController.suppliers);
module.exports = appRouter;
