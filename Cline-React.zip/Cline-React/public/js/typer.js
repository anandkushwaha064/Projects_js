
let options = {
    strings: ["This is the Future!", "Welcome to WeConnect","Built to change Businesses","Register to up your game"],
    typeSpeed: 100,
    loop: true,
    backSpeed: 6,
    showCursor: false
}
  
let typed = new Typed(".cover-heading", options);